import type { FastifyRequest } from 'fastify';
export type AuthUser = { id: string };
export type AuthResolver = (request: FastifyRequest) => Promise<AuthUser | null> | AuthUser | null;
export type AccessChecker = (user: AuthUser, action: string, condominioId?: number) => Promise<boolean> | boolean;
// Modo integrated: conecte aqui o Better Auth e as permissões do backend principal.
// Por segurança, sem integração explícita o acesso é negado.
export const denyUntilIntegrated: AuthResolver = () => null;
export const denyPermissionsUntilIntegrated: AccessChecker = () => false;
export const demoResolver: AuthResolver = (request) => {
  const header = request.headers['x-demo-user-id'];
  return typeof header === 'string' && header.trim() ? { id: header } : null;
};
