import mysql from 'mysql2/promise';
import { drizzle } from 'drizzle-orm/mysql2';
import * as schema from './schema.js';

export function createDb() {
  const url = process.env.DATABASE_URL;
  if (!url || !url.startsWith('mysql://')) {
    throw new Error('Configure DATABASE_URL=mysql://usuario:senha@localhost:3306/condominio no .env');
  }
  const pool = mysql.createPool({ uri: url, waitForConnections: true, connectionLimit: 10 });
  return { db: drizzle(pool, { schema, mode: 'default' }), pool };
}
export type AppDb = ReturnType<typeof createDb>['db'];
