import { mysqlTable, int, varchar, text, check, index } from 'drizzle-orm/mysql-core';
import { sql } from 'drizzle-orm';

// Referências externas (condominio, unidade, area_comum, usuario) ficam sem FK local
// até a integração com as tabelas dos demais integrantes.
const id = (name: string) => int(name);
const date = (name: string) => varchar(name, { length: 40 }); // ISO 8601 com fuso, preservado do projeto original
const userId = (name: string) => varchar(name, { length: 191 });
const status = (name: string) => varchar(name, { length: 40 });

export const prestador = mysqlTable('prestador', {
  id: int('id').autoincrement().primaryKey(),
  nome: varchar('nome', { length: 255 }).notNull(),
  documento: varchar('documento', { length: 100 }),
  telefone: varchar('telefone', { length: 50 }),
  email: varchar('email', { length: 255 }),
  status: status('status').notNull().default('ativo'),
});
export const ocorrencia = mysqlTable('ocorrencia', {
  id: int('id').autoincrement().primaryKey(),
  condominioId: id('condominio_id').notNull(),
  autorId: userId('autor_id').notNull(),
  unidadeId: id('unidade_id'), areaComumId: id('area_comum_id'),
  categoria: varchar('categoria', { length: 100 }).notNull(),
  titulo: varchar('titulo', { length: 255 }).notNull(),
  descricao: text('descricao').notNull(),
  prioridade: status('prioridade').notNull(),
  status: status('status').notNull().default('aberta'),
  criadoEm: date('criado_em').notNull(), encerradoEm: date('encerrado_em'),
  providencia: text('providencia'), encerradoPor: userId('encerrado_por'),
}, (t) => [
  check('ocorrencia_local_exclusivo', sql`NOT (${t.unidadeId} IS NOT NULL AND ${t.areaComumId} IS NOT NULL)`),
  index('ocorrencia_condominio_idx').on(t.condominioId),
]);
export const ordemServico = mysqlTable('ordem_servico', {
  id: int('id').autoincrement().primaryKey(),
  condominioId: id('condominio_id').notNull(),
  ocorrenciaId: id('ocorrencia_id').references(() => ocorrencia.id, { onDelete: 'restrict' }),
  unidadeId: id('unidade_id'), descricao: text('descricao').notNull(),
  localDescricao: text('local_descricao'),
  inicioPrevisto: date('inicio_previsto'), fimPrevisto: date('fim_previsto'),
  inicioReal: date('inicio_real'), fimReal: date('fim_real'),
  status: status('status').notNull().default('pendente'), criadoEm: date('criado_em').notNull(),
}, (t) => [index('ordem_servico_condominio_idx').on(t.condominioId)]);
export const atribuicaoOs = mysqlTable('atribuicao_os', {
  id: int('id').autoincrement().primaryKey(),
  ordemServicoId: id('ordem_servico_id').notNull().references(() => ordemServico.id, { onDelete: 'restrict' }),
  usuarioExecutorId: userId('usuario_executor_id'),
  prestadorExecutorId: id('prestador_executor_id').references(() => prestador.id, { onDelete: 'restrict' }),
  atribuidoPor: userId('atribuido_por').notNull(), inicio: date('inicio').notNull(), fim: date('fim'),
  motivoAlteracao: text('motivo_alteracao'),
}, (t) => [
  check('atribuicao_executor_xor', sql`(${t.usuarioExecutorId} IS NOT NULL AND ${t.prestadorExecutorId} IS NULL) OR (${t.usuarioExecutorId} IS NULL AND ${t.prestadorExecutorId} IS NOT NULL)`),
  index('atribuicao_os_ordem_idx').on(t.ordemServicoId),
]);
export const comunicado = mysqlTable('comunicado', {
  id: int('id').autoincrement().primaryKey(),
  condominioId: id('condominio_id').notNull(), autorId: userId('autor_id').notNull(),
  titulo: varchar('titulo', { length: 255 }).notNull(), conteudo: text('conteudo').notNull(),
  audienciaGeral: int('audiencia_geral').notNull().default(1),
  status: status('status').notNull().default('rascunho'),
  publicadoEm: date('publicado_em'), expiraEm: date('expira_em'),
}, (t) => [
  check('comunicado_audiencia_boolean', sql`${t.audienciaGeral} IN (0,1)`),
  index('comunicado_condominio_idx').on(t.condominioId),
]);
export const notificacao = mysqlTable('notificacao', {
  id: int('id').autoincrement().primaryKey(),
  condominioId: id('condominio_id').notNull(), destinatarioId: userId('destinatario_id').notNull(),
  tipo: varchar('tipo', { length: 100 }).notNull(),
  titulo: varchar('titulo', { length: 255 }).notNull(), mensagem: text('mensagem').notNull(),
  criadoEm: date('criado_em').notNull(), lidoEm: date('lido_em'),
}, (t) => [index('notificacao_condominio_idx').on(t.condominioId)]);
