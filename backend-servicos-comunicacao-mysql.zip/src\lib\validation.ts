import { z } from 'zod';
const id = z.number().int().positive();
const nonempty = z.string().trim().min(1);
const date = z.string().datetime({ offset: true });
const nullable = <T extends z.ZodTypeAny>(schema: T) => schema.nullable().optional();
export const schemas = {
  prestador: z.object({ nome: nonempty, documento: nullable(z.string()), telefone: nullable(z.string()), email: nullable(z.string().email()), status: z.enum(['ativo','inativo']).default('ativo') }),
  ocorrencia: z.object({ condominioId: id, autorId: nonempty, unidadeId: nullable(id), areaComumId: nullable(id), categoria: nonempty, titulo: nonempty, descricao: nonempty, prioridade: z.enum(['baixa','media','alta','urgente']), status: z.enum(['aberta','em_andamento','encerrada','cancelada']).default('aberta'), providencia: nullable(z.string()), encerradoEm: nullable(date), encerradoPor: nullable(nonempty) }),
  ordemServico: z.object({ condominioId: id, ocorrenciaId: nullable(id), unidadeId: nullable(id), descricao: nonempty, localDescricao: nullable(z.string()), inicioPrevisto: nullable(date), fimPrevisto: nullable(date), inicioReal: nullable(date), fimReal: nullable(date), status: z.enum(['pendente','em_andamento','concluida','cancelada']).default('pendente') }),
  atribuicaoOs: z.object({ ordemServicoId: id, usuarioExecutorId: nullable(nonempty), prestadorExecutorId: nullable(id), atribuidoPor: nonempty, inicio: date, fim: nullable(date), motivoAlteracao: nullable(z.string()) }),
  comunicado: z.object({ condominioId: id, autorId: nonempty, titulo: nonempty, conteudo: nonempty, audienciaGeral: z.union([z.literal(0),z.literal(1)]).default(1), status: z.enum(['rascunho','publicado','arquivado']).default('rascunho'), publicadoEm: nullable(date), expiraEm: nullable(date) }),
  notificacao: z.object({ condominioId: id, destinatarioId: nonempty, tipo: nonempty, titulo: nonempty, mensagem: nonempty, lidoEm: nullable(date) }),
};
export const idParams = z.object({ id: z.coerce.number().int().positive() });
export const listQuery = z.object({ condominioId: z.coerce.number().int().positive().optional(), page: z.coerce.number().int().min(1).default(1), limit: z.coerce.number().int().min(1).max(100).default(20) });
export function validateBusiness(table: keyof typeof schemas, value: Record<string, unknown>) {
  if (table === 'ocorrencia' && value.unidadeId != null && value.areaComumId != null) throw new Error('Informe unidadeId OU areaComumId, nunca ambos.');
  if (table === 'atribuicaoOs' && ((value.usuarioExecutorId != null) === (value.prestadorExecutorId != null))) throw new Error('Informe exatamente um executor: usuarioExecutorId OU prestadorExecutorId.');
  if (table === 'ordemServico') for (const [a,b] of [['inicioPrevisto','fimPrevisto'],['inicioReal','fimReal']]) if (value[a] && value[b] && String(value[b]) <= String(value[a])) throw new Error(`${b} deve ser posterior a ${a}.`);
  if (table === 'atribuicaoOs' && value.fim && String(value.fim) <= String(value.inicio)) throw new Error('fim deve ser posterior a inicio.');
  if (table === 'ocorrencia' && value.status === 'encerrada' && (!value.encerradoEm || !value.encerradoPor)) throw new Error('Ocorrência encerrada exige encerradoEm e encerradoPor.');
}
