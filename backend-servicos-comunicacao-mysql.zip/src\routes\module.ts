import type { FastifyInstance } from 'fastify';
import { eq, and, count, desc, sql } from 'drizzle-orm';
import { z } from 'zod';
import type { AppDb } from '../db/index.js';
import * as t from '../db/schema.js';
import { schemas, idParams, listQuery, validateBusiness } from '../lib/validation.js';
import type { AuthResolver, AccessChecker } from '../lib/auth.js';
import { denyUntilIntegrated, denyPermissionsUntilIntegrated } from '../lib/auth.js';

type Name = keyof typeof schemas;
type AnyTable = typeof t.prestador | typeof t.ocorrencia | typeof t.ordemServico | typeof t.atribuicaoOs | typeof t.comunicado | typeof t.notificacao;
const resources: { name: Name; path: string; table: AnyTable; scoped: boolean }[] = [
  { name:'prestador', path:'prestadores', table:t.prestador, scoped:false },
  { name:'ocorrencia', path:'ocorrencias', table:t.ocorrencia, scoped:true },
  { name:'ordemServico', path:'ordens-servico', table:t.ordemServico, scoped:true },
  { name:'atribuicaoOs', path:'atribuicoes-os', table:t.atribuicaoOs, scoped:false },
  { name:'comunicado', path:'comunicados', table:t.comunicado, scoped:true },
  { name:'notificacao', path:'notificacoes', table:t.notificacao, scoped:true },
];
const now = () => new Date().toISOString();
export type ModuleOptions = { db: AppDb; resolveUser?: AuthResolver; canAccess?: AccessChecker };
export async function registerServicosComunicacao(app: FastifyInstance, options: ModuleOptions) {
  const { db, resolveUser = denyUntilIntegrated, canAccess = denyPermissionsUntilIntegrated } = options;
  // Dynamic table types are intentionally isolated here; runtime data is validated by Zod.
  const database = db as any;
  for (const r of resources) {
    const table = r.table as any;
    const base = `/api/${r.path}`;
    const authorize = async (request: any, reply: any, action: string, condominioId?: number) => {
      const user = await resolveUser(request);
      if (!user) { reply.code(401).send({ error:'Não autenticado' }); return false; }
      if (!(await canAccess(user, `${r.name}:${action}`, condominioId))) { reply.code(403).send({ error:'Sem permissão' }); return false; }
      return true;
    };
    app.get(base, async (request, reply) => {
      const q = listQuery.parse(request.query);
      if (r.scoped && !q.condominioId) return reply.code(400).send({ error:'condominioId é obrigatório na listagem' });
      if (!await authorize(request, reply, 'read', q.condominioId)) return;
      const where = r.scoped ? eq(table.condominioId, q.condominioId) : undefined;
      const [rows, totals] = await Promise.all([
        database.select().from(table).where(where).orderBy(desc(table.id)).limit(q.limit).offset((q.page-1)*q.limit),
        database.select({ total: count() }).from(table).where(where),
      ]);
      return { data:rows, page:q.page, limit:q.limit, total:totals[0]?.total ?? 0 };
    });
    app.get(`${base}/:id`, async (request, reply) => {
      const { id } = idParams.parse(request.params);
      const [row] = await database.select().from(table).where(eq(table.id,id)).limit(1);
      if (!row) return reply.code(404).send({ error:'Registro não encontrado' });
      if (!await authorize(request,reply,'read',row.condominioId)) return;
      return { data:row };
    });
    app.post(base, async (request,reply) => {
      const data = schemas[r.name].strict().parse(request.body) as Record<string,any>;
      validateBusiness(r.name,data);
      if (!await authorize(request,reply,'create',data.condominioId)) return;
      if (r.name === 'ordemServico' && data.ocorrenciaId) {
        const [origin] = await db.select().from(t.ocorrencia).where(eq(t.ocorrencia.id,data.ocorrenciaId)).limit(1);
        if (!origin || origin.condominioId !== data.condominioId) return reply.code(400).send({error:'Ocorrência não pertence ao condomínio informado'});
      }
      if (r.name === 'atribuicaoOs') {
        const [order] = await db.select().from(t.ordemServico).where(eq(t.ordemServico.id,data.ordemServicoId)).limit(1);
        if (!order) return reply.code(400).send({error:'Ordem de serviço inexistente'});
        if (!await authorize(request,reply,'create',order.condominioId)) return;
      }
      if (r.name === 'atribuicaoOs' && data.fim == null) {
        const [vigente] = await db.select({ id: t.atribuicaoOs.id }).from(t.atribuicaoOs)
          .where(and(eq(t.atribuicaoOs.ordemServicoId, data.ordemServicoId), sql`${t.atribuicaoOs.fim} IS NULL`)).limit(1);
        if (vigente) return reply.code(409).send({ error: 'Já existe atribuição vigente para esta ordem de serviço' });
      }
      if (r.name === 'ocorrencia' || r.name === 'ordemServico' || r.name === 'notificacao') data.criadoEm = now();
      if (r.name === 'comunicado' && data.status === 'publicado' && !data.publicadoEm) data.publicadoEm = now();
      // MySQL não oferece INSERT ... RETURNING como SQLite; buscar pelo insertId.
      const [insertResult] = await database.insert(table).values(data);
      const [created] = await database.select().from(table).where(eq(table.id, insertResult.insertId)).limit(1);
      return reply.code(201).send({data:created});
    });
    app.patch(`${base}/:id`, async (request,reply) => {
      const {id} = idParams.parse(request.params);
      const [existing] = await database.select().from(table).where(eq(table.id,id)).limit(1);
      if (!existing) return reply.code(404).send({error:'Registro não encontrado'});
      if (!await authorize(request,reply,'update',existing.condominioId)) return;
      const patch = schemas[r.name].partial().strict().parse(request.body) as Record<string,any>;
      if (!Object.keys(patch).length) return reply.code(400).send({error:'Envie ao menos um campo'});
      // Evita transferência silenciosa entre condomínios e alteração de responsáveis históricos.
      for (const key of ['condominioId','autorId','atribuidoPor','ordemServicoId','destinatarioId']) {
        if (key in patch && patch[key] !== existing[key]) return reply.code(400).send({error:`Campo imutável: ${key}`});
      }
      if (r.name === 'atribuicaoOs' && 'fim' in patch && patch.fim == null && existing.fim != null) {
        const [vigente] = await db.select({ id: t.atribuicaoOs.id }).from(t.atribuicaoOs)
          .where(and(eq(t.atribuicaoOs.ordemServicoId, existing.ordemServicoId), sql`${t.atribuicaoOs.fim} IS NULL`)).limit(1);
        if (vigente) return reply.code(409).send({ error: 'Já existe atribuição vigente para esta ordem de serviço' });
      }
      const merged = {...existing,...patch};
      validateBusiness(r.name,merged);
      if (r.name === 'ordemServico' && merged.ocorrenciaId) {
        const [origin] = await db.select().from(t.ocorrencia).where(eq(t.ocorrencia.id,merged.ocorrenciaId)).limit(1);
        if (!origin || origin.condominioId !== merged.condominioId) return reply.code(400).send({error:'Ocorrência não pertence ao condomínio'});
      }
      if (r.name === 'comunicado' && merged.status === 'publicado' && !merged.publicadoEm) patch.publicadoEm = now();
      await database.update(table).set(patch).where(eq(table.id,id));
      const [updated] = await database.select().from(table).where(eq(table.id,id)).limit(1);
      return {data:updated};
    });
    app.delete(`${base}/:id`, async (request,reply) => {
      const {id} = idParams.parse(request.params);
      const [existing] = await database.select().from(table).where(eq(table.id,id)).limit(1);
      if (!existing) return reply.code(404).send({error:'Registro não encontrado'});
      if (!await authorize(request,reply,'delete',existing.condominioId)) return;
      // Exclusão física é apenas demonstrativa; em produção preferir política de retenção e auditoria.
      await database.delete(table).where(eq(table.id,id));
      return reply.code(204).send();
    });
  }
  app.patch('/api/notificacoes/:id/ler', async (request,reply) => {
    const {id} = idParams.parse(request.params);
    const user = await resolveUser(request);
    if (!user) return reply.code(401).send({error:'Não autenticado'});
    const [notification] = await db.select().from(t.notificacao).where(eq(t.notificacao.id,id)).limit(1);
    if (!notification) return reply.code(404).send({error:'Notificação não encontrada'});
    if (notification.destinatarioId !== user.id) return reply.code(403).send({error:'Apenas o destinatário pode marcar como lida'});
    if (!await canAccess(user,'notificacao:read',notification.condominioId)) return reply.code(403).send({error:'Sem permissão'});
    await db.update(t.notificacao).set({lidoEm:notification.lidoEm ?? now()}).where(eq(t.notificacao.id,id));
    const [updated] = await db.select().from(t.notificacao).where(eq(t.notificacao.id,id)).limit(1);
    return {data:updated};
  });
}
