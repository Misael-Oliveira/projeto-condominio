import 'dotenv/config';
import Fastify from 'fastify';
import { ZodError } from 'zod';
import { createDb } from './db/index.js';
import { registerServicosComunicacao } from './routes/module.js';
import { demoResolver, denyUntilIntegrated } from './lib/auth.js';

const app = Fastify({ logger: true });
const { db, pool } = createDb();
const demo = process.env.AUTH_MODE === 'demo' && process.env.NODE_ENV !== 'production';
app.setErrorHandler((error, request, reply) => {
  if (error instanceof ZodError) return reply.code(400).send({ error: 'Dados inválidos', detalhes: error.issues });
  const mensagem = error instanceof Error ? error.message : String(error);
  if (mensagem.includes('ER_DUP_ENTRY') || mensagem.includes('ER_NO_REFERENCED_ROW') || mensagem.includes('ER_ROW_IS_REFERENCED') || mensagem.includes('ER_CHECK_CONSTRAINT_VIOLATED')) {
    return reply.code(409).send({ error: 'Restrição de integridade violada' });
  }
  if (['Informe ', 'fim deve', 'Ocorrência encerrada'].some((s) => mensagem.startsWith(s))) {
    return reply.code(400).send({ error: mensagem });
  }
  request.log.error(error);
  return reply.code(500).send({ error: 'Erro interno do servidor' });
});
app.get('/health', async () => ({ status:'ok', modulo:'servicos-comunicacao' }));
await registerServicosComunicacao(app, {
  db,
  resolveUser: demo ? demoResolver : denyUntilIntegrated,
  canAccess: demo ? () => true : () => false,
});
await app.ready();
console.log(app.printRoutes());
app.addHook('onClose', async () => pool.end());
await app.listen({ port:Number(process.env.PORT ?? 3001), host:'127.0.0.1' });

