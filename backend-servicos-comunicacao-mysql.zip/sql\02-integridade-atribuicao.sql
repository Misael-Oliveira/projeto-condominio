-- Execute após npm run db:push, no MySQL 8.0+.
-- Em SQLite havia índice único parcial (fim IS NULL).
-- MySQL não possui índice parcial equivalente: coluna gerada + UNIQUE
-- impede mais de uma atribuição vigente por ordem, sem limitar histórico.
ALTER TABLE atribuicao_os
  ADD COLUMN ordem_vigente INT GENERATED ALWAYS AS (
    CASE WHEN fim IS NULL THEN ordem_servico_id ELSE NULL END
  ) STORED,
  ADD UNIQUE INDEX atribuicao_os_uma_vigente (ordem_vigente);
-- Não execute duas vezes. Se integrar ao schema principal, incorporar na migration central.
