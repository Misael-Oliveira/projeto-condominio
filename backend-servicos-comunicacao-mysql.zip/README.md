# Backend — Serviços e Comunicação (MySQL)

**Versão separada** do módulo original SQLite. Mantidos TypeScript, Fastify, Drizzle ORM, Zod, os seis recursos e seus caminhos `/api/...`.

## Pré-requisitos
- Node.js 20+ e **MySQL 8.0.16+** instalado e em execução.
- Um usuário MySQL com permissão para criar/alterar tabelas no banco de desenvolvimento.

## Configuração no Windows (PowerShell)
1. Extraia este ZIP em uma **nova pasta**; não substitua a pasta SQLite original.
2. Execute `npm.cmd install` (baixa `mysql2` e gera novo `package-lock.json`).
3. No MySQL Workbench ou cliente MySQL, execute `sql/01-criar-banco.sql`.
4. Execute `Copy-Item .env.example .env` e ajuste **SUA_SENHA** e usuário MySQL. Se a senha tiver caracteres reservados (`@`, `#`, `:`, `/`, `%`), codifique-os para URL.
5. Execute `npm.cmd run check` e `npm.cmd run db:push`.
6. Execute **uma única vez** `sql/02-integridade-atribuicao.sql` no MySQL para recriar a regra de uma atribuição vigente por OS.
7. Execute `npm.cmd run dev` em um terminal, mantendo-o aberto.
8. Em **outro** terminal, teste `curl.exe -i http://127.0.0.1:3001/health`.

## Teste de cadastro
```powershell
$headers = @{ 'x-demo-user-id' = 'usuario-teste-1' }
$body = @{ nome = 'João da Silva'; status = 'ativo' } | ConvertTo-Json
Invoke-RestMethod -Uri 'http://127.0.0.1:3001/api/prestadores' -Method POST -Headers $headers -ContentType 'application/json' -Body $body
Invoke-RestMethod -Uri 'http://127.0.0.1:3001/api/prestadores' -Headers $headers
```

## Endpoints mantidos
`/api/prestadores`, `/api/ocorrencias`, `/api/ordens-servico`, `/api/atribuicoes-os`, `/api/comunicados`, `/api/notificacoes`: GET lista, GET por ID, POST, PATCH por ID e DELETE por ID.
`PATCH /api/notificacoes/:id/ler` marca como lida.
Listagens vinculadas a condomínio exigem `?condominioId=1`.
Veja `examples/requests.http`.

## Integração e ressalvas
- **Não foi possível testar conexão real**: é necessário um servidor MySQL com credenciais. `db:push` e os endpoints precisam ser executados no seu computador.
- A regra de **uma atribuição vigente por OS** depende do SQL complementar. Há verificação na aplicação, mas só o índice único gerado protege de concorrência.
- IDs de `usuario`, `condominio`, `unidade`, `area_comum` continuam sem FKs locais, porque essas tabelas pertencem aos módulos dos colegas. Criar FKs e checar vínculos na integração.
- O `AUTH_MODE=demo` é **exclusivo para testes locais**, com header `x-demo-user-id`; no modo integrado a autenticação e as permissões negam acesso até conectar Better Auth.
- Datas continuam em texto ISO 8601, para manter o contrato JSON anterior. Para um produto final, considerar DATETIME/TIMESTAMP e padronização UTC.
- O `DELETE` continua físico como na versão acadêmica original. Não há migração automática dos registros SQLite antigos para MySQL; o banco MySQL inicia vazio.
- O projeto original não foi modificado. `node_modules`, arquivos `.db` e `.env` reais não estão incluídos neste ZIP.
